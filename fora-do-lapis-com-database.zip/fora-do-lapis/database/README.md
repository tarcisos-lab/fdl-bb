# Database SQLite — Fora do Lápis

Pasta com banco **SQLite funcional** alinhado ao sistema de agendamento de aulas.

## Arquivos

| Arquivo | Descrição |
|---------|-----------|
| `fora_do_lapis.db` | Banco SQLite pronto (com dados demo) |
| `schema.sql` | DDL completo (tabelas, índices, triggers) |
| `seed.sql` | Snapshot legível dos dados iniciais |
| `db_api.py` | API Python para registrar, login, agendar, logs |
| `README.md` | Esta documentação |

## Tabelas

1. **usuarios** — cadastro base (aluno / professor / admin)
2. **credenciais** — hash de senha, tentativas, bloqueio, último login
3. **perfis_aluno** — dados específicos do aluno
4. **perfis_professor** — disciplina, bio, formação, valor/hora
5. **disciplinas** — catálogo
6. **agendamentos** — solicitações e aulas (`pendente`, `confirmada`, `recusada`, `cancelada`, `concluida`)
7. **historico_acessos** — log de tentativas de login (sucesso/falha, IP, UA)
8. **historico_acoes** — auditoria (cadastro, solicitar_aula, aceitar_aula, etc.)
9. **sessoes** — tokens de sessão com expiração
10. **app_config** — configurações da aplicação

## Contas demo

| Tipo | E-mail | Senha |
|------|--------|-------|
| Professor | gabriel@email.com | 123456 |
| Professor | mariana@email.com | 123456 |
| Professor | lucas@email.com | 123456 |
| Aluno | ana@email.com | 123456 |

> Senhas armazenadas como **SHA-256 + salt** (`fora-do-lapis-v1`). Em produção, prefira bcrypt/argon2.

## Como usar (Python)

```bash
cd database
python3 db_api.py demo
python3 db_api.py listar-users
python3 db_api.py listar-profs
```

```python
from db_api import Database

db = Database()

# Registrar
uid = db.registrar_aluno("João", "joao@email.com", "senha123")
pid = db.registrar_professor("Maria", "maria@email.com", "senha123", "Física")

# Login
sess = db.login("joao@email.com", "senha123", ip="1.2.3.4")
# sess = { id, nome, email, tipo, token, expira_em, perfil }

# Solicitar aula
ag_id = db.solicitar_aula(
    aluno_id=sess["id"],
    professor_id=pid,
    disciplina="Física",
    data="2026-10-01",
    horario="16:00",
)

# Professor responde
db.responder_solicitacao(professor_id=pid, agendamento_id=ag_id, status="confirmada")

# Listagens
db.listar_solicitacoes_professor(pid)
db.listar_aulas_aluno(sess["id"])
db.listar_acessos(usuario_id=sess["id"])
db.listar_acoes(usuario_id=sess["id"])
```

## Recriar o banco do zero

```bash
cd database
rm -f fora_do_lapis.db
python3 -c "
import sqlite3
from pathlib import Path
schema = Path('schema.sql').read_text()
conn = sqlite3.connect('fora_do_lapis.db')
conn.executescript(schema)
conn.close()
print('schema ok')
"
# depois rode o seed via db_api ou insira dados manualmente
```

## Integração futura com o front-end

Hoje o site usa `localStorage`. Para usar este banco de verdade:

1. Subir um backend (Flask/FastAPI/Express) que chama `db_api.py` ou SQL equivalente
2. Expor endpoints REST (`/login`, `/agendar`, `/solicitacoes`, …)
3. Trocar o `app.js` para chamar a API em vez de `localStorage`

O modelo de dados já cobre o fluxo de **solicitação → aceite/recusa → aula confirmada** implementado no front.

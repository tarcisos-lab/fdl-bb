PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT    NOT NULL,
    email           TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    tipo            TEXT    NOT NULL CHECK (tipo IN ('aluno', 'professor', 'admin')),
    ativo           INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0, 1)),
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    atualizado_em   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_usuarios_tipo  ON usuarios(tipo);

CREATE TABLE IF NOT EXISTS credenciais (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NOT NULL UNIQUE,
    senha_hash      TEXT    NOT NULL,
    algoritmo       TEXT    NOT NULL DEFAULT 'sha256-salt',
    tentativas_falha INTEGER NOT NULL DEFAULT 0,
    bloqueado_ate   TEXT    NULL,
    ultimo_login    TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    atualizado_em   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS perfis_aluno (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NOT NULL UNIQUE,
    telefone        TEXT    NULL,
    serie_escolar   TEXT    NULL,
    escola          TEXT    NULL,
    preferencias    TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    atualizado_em   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS perfis_professor (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NOT NULL UNIQUE,
    disciplina      TEXT    NOT NULL,
    bio             TEXT    DEFAULT '',
    formacao        TEXT    NULL,
    valor_hora      REAL    NULL,
    avaliacao_media REAL    DEFAULT 5.0,
    telefone        TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    atualizado_em   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_prof_disciplina ON perfis_professor(disciplina);

CREATE TABLE IF NOT EXISTS disciplinas (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT    NOT NULL UNIQUE,
    descricao       TEXT    NULL,
    ativa           INTEGER NOT NULL DEFAULT 1,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS agendamentos (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id        INTEGER NOT NULL,
    professor_id    INTEGER NOT NULL,
    disciplina      TEXT    NOT NULL,
    data            TEXT    NOT NULL,
    horario         TEXT    NOT NULL,
    status          TEXT    NOT NULL DEFAULT 'pendente'
                        CHECK (status IN ('pendente', 'confirmada', 'recusada', 'cancelada', 'concluida')),
    observacao      TEXT    NULL,
    respondido_em   TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    atualizado_em   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (aluno_id)     REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (professor_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ag_aluno      ON agendamentos(aluno_id);
CREATE INDEX IF NOT EXISTS idx_ag_professor  ON agendamentos(professor_id);
CREATE INDEX IF NOT EXISTS idx_ag_status     ON agendamentos(status);
CREATE INDEX IF NOT EXISTS idx_ag_data       ON agendamentos(data);

CREATE TABLE IF NOT EXISTS historico_acessos (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NULL,
    email_tentativa TEXT    NULL,
    sucesso         INTEGER NOT NULL CHECK (sucesso IN (0, 1)),
    ip              TEXT    NULL,
    user_agent      TEXT    NULL,
    mensagem        TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_acessos_usuario ON historico_acessos(usuario_id);
CREATE INDEX IF NOT EXISTS idx_acessos_data    ON historico_acessos(criado_em);

CREATE TABLE IF NOT EXISTS historico_acoes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NULL,
    acao            TEXT    NOT NULL,
    entidade        TEXT    NULL,
    entidade_id     INTEGER NULL,
    detalhes        TEXT    NULL,
    ip              TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_acoes_usuario ON historico_acoes(usuario_id);
CREATE INDEX IF NOT EXISTS idx_acoes_acao    ON historico_acoes(acao);
CREATE INDEX IF NOT EXISTS idx_acoes_data    ON historico_acoes(criado_em);

CREATE TABLE IF NOT EXISTS sessoes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id      INTEGER NOT NULL,
    token           TEXT    NOT NULL UNIQUE,
    expira_em       TEXT    NOT NULL,
    ip              TEXT    NULL,
    user_agent      TEXT    NULL,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sessoes_token ON sessoes(token);
CREATE INDEX IF NOT EXISTS idx_sessoes_user  ON sessoes(usuario_id);

CREATE TABLE IF NOT EXISTS app_config (
    chave           TEXT PRIMARY KEY,
    valor           TEXT NOT NULL,
    atualizado_em   TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TRIGGER IF NOT EXISTS trg_usuarios_updated
AFTER UPDATE ON usuarios
BEGIN
    UPDATE usuarios SET atualizado_em = datetime('now', 'localtime') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_credenciais_updated
AFTER UPDATE ON credenciais
BEGIN
    UPDATE credenciais SET atualizado_em = datetime('now', 'localtime') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_agendamentos_updated
AFTER UPDATE ON agendamentos
BEGIN
    UPDATE agendamentos SET atualizado_em = datetime('now', 'localtime') WHERE id = NEW.id;
END;

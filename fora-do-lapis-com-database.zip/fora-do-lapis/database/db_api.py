#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API de acesso ao SQLite — Fora do Lápis
Uso:
  python db_api.py demo          # roda exemplos
  python db_api.py listar-users
  from db_api import Database
"""

from __future__ import annotations

import hashlib
import json
import secrets
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

DB_PATH = Path(__file__).resolve().parent / "fora_do_lapis.db"
SALT = "fora-do-lapis-v1"


def hash_senha(senha: str) -> str:
    return hashlib.sha256(f"{SALT}:{senha}".encode("utf-8")).hexdigest()


def verificar_senha(senha: str, senha_hash: str) -> bool:
    return hash_senha(senha) == senha_hash


class Database:
    def __init__(self, path: Path | str = DB_PATH):
        self.path = Path(path)
        if not self.path.exists():
            raise FileNotFoundError(f"Banco não encontrado: {self.path}")

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    # ---------- Usuários / registro ----------

    def registrar_aluno(
        self,
        nome: str,
        email: str,
        senha: str,
        serie_escolar: str | None = None,
        escola: str | None = None,
        ip: str | None = None,
    ) -> int:
        with self._conn() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO usuarios (nome, email, tipo) VALUES (?, ?, 'aluno')",
                (nome, email),
            )
            uid = cur.lastrowid
            cur.execute(
                "INSERT INTO credenciais (usuario_id, senha_hash) VALUES (?, ?)",
                (uid, hash_senha(senha)),
            )
            cur.execute(
                "INSERT INTO perfis_aluno (usuario_id, serie_escolar, escola) VALUES (?, ?, ?)",
                (uid, serie_escolar, escola),
            )
            self._log_acao(cur, uid, "cadastro", "usuario", uid, {"tipo": "aluno"}, ip)
            conn.commit()
            return uid

    def registrar_professor(
        self,
        nome: str,
        email: str,
        senha: str,
        disciplina: str,
        bio: str = "",
        ip: str | None = None,
    ) -> int:
        with self._conn() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO usuarios (nome, email, tipo) VALUES (?, ?, 'professor')",
                (nome, email),
            )
            uid = cur.lastrowid
            cur.execute(
                "INSERT INTO credenciais (usuario_id, senha_hash) VALUES (?, ?)",
                (uid, hash_senha(senha)),
            )
            cur.execute(
                "INSERT INTO perfis_professor (usuario_id, disciplina, bio) VALUES (?, ?, ?)",
                (uid, disciplina, bio),
            )
            self._log_acao(
                cur, uid, "cadastro", "usuario", uid,
                {"tipo": "professor", "disciplina": disciplina}, ip,
            )
            conn.commit()
            return uid

    # ---------- Login / credenciais ----------

    def login(
        self,
        email: str,
        senha: str,
        ip: str | None = None,
        user_agent: str | None = None,
    ) -> Optional[dict]:
        with self._conn() as conn:
            cur = conn.cursor()
            row = cur.execute(
                """
                SELECT u.*, c.senha_hash, c.tentativas_falha, c.bloqueado_ate
                FROM usuarios u
                JOIN credenciais c ON c.usuario_id = u.id
                WHERE u.email = ? COLLATE NOCASE AND u.ativo = 1
                """,
                (email,),
            ).fetchone()

            if not row:
                cur.execute(
                    """INSERT INTO historico_acessos
                       (usuario_id, email_tentativa, sucesso, ip, user_agent, mensagem)
                       VALUES (NULL, ?, 0, ?, ?, ?)""",
                    (email, ip, user_agent, "Conta não encontrada"),
                )
                conn.commit()
                return None

            if row["bloqueado_ate"]:
                try:
                    if datetime.fromisoformat(row["bloqueado_ate"]) > datetime.now():
                        cur.execute(
                            """INSERT INTO historico_acessos
                               (usuario_id, email_tentativa, sucesso, ip, user_agent, mensagem)
                               VALUES (?, ?, 0, ?, ?, ?)""",
                            (row["id"], email, ip, user_agent, "Conta temporariamente bloqueada"),
                        )
                        conn.commit()
                        return None
                except ValueError:
                    pass

            if not verificar_senha(senha, row["senha_hash"]):
                falhas = (row["tentativas_falha"] or 0) + 1
                bloqueado = None
                if falhas >= 5:
                    bloqueado = (datetime.now() + timedelta(minutes=15)).isoformat(timespec="seconds")
                    falhas = 0
                cur.execute(
                    "UPDATE credenciais SET tentativas_falha = ?, bloqueado_ate = ? WHERE usuario_id = ?",
                    (falhas, bloqueado, row["id"]),
                )
                cur.execute(
                    """INSERT INTO historico_acessos
                       (usuario_id, email_tentativa, sucesso, ip, user_agent, mensagem)
                       VALUES (?, ?, 0, ?, ?, ?)""",
                    (row["id"], email, ip, user_agent, "Senha incorreta"),
                )
                conn.commit()
                return None

            # sucesso
            agora = datetime.now().isoformat(timespec="seconds")
            cur.execute(
                """UPDATE credenciais
                   SET tentativas_falha = 0, bloqueado_ate = NULL, ultimo_login = ?
                   WHERE usuario_id = ?""",
                (agora, row["id"]),
            )
            cur.execute(
                """INSERT INTO historico_acessos
                   (usuario_id, email_tentativa, sucesso, ip, user_agent, mensagem)
                   VALUES (?, ?, 1, ?, ?, ?)""",
                (row["id"], email, ip, user_agent, "Login bem-sucedido"),
            )
            token = secrets.token_urlsafe(32)
            expira = (datetime.now() + timedelta(hours=24)).isoformat(timespec="seconds")
            cur.execute(
                "INSERT INTO sessoes (usuario_id, token, expira_em, ip, user_agent) VALUES (?,?,?,?,?)",
                (row["id"], token, expira, ip, user_agent),
            )
            self._log_acao(cur, row["id"], "login", "sessao", None, {"token_prefix": token[:8]}, ip)
            conn.commit()

            perfil = self.obter_perfil(row["id"], conn=conn)
            return {
                "id": row["id"],
                "nome": row["nome"],
                "email": row["email"],
                "tipo": row["tipo"],
                "token": token,
                "expira_em": expira,
                "perfil": perfil,
            }

    def validar_sessao(self, token: str) -> Optional[dict]:
        with self._conn() as conn:
            row = conn.execute(
                """
                SELECT s.*, u.nome, u.email, u.tipo, u.ativo
                FROM sessoes s
                JOIN usuarios u ON u.id = s.usuario_id
                WHERE s.token = ?
                """,
                (token,),
            ).fetchone()
            if not row or not row["ativo"]:
                return None
            if datetime.fromisoformat(row["expira_em"]) < datetime.now():
                conn.execute("DELETE FROM sessoes WHERE id = ?", (row["id"],))
                conn.commit()
                return None
            return {
                "id": row["usuario_id"],
                "nome": row["nome"],
                "email": row["email"],
                "tipo": row["tipo"],
                "token": token,
            }

    def logout(self, token: str) -> None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT usuario_id FROM sessoes WHERE token = ?", (token,)
            ).fetchone()
            conn.execute("DELETE FROM sessoes WHERE token = ?", (token,))
            if row:
                self._log_acao(conn.cursor(), row["usuario_id"], "logout", "sessao", None, None)
            conn.commit()

    # ---------- Perfis ----------

    def obter_perfil(self, usuario_id: int, conn: sqlite3.Connection | None = None) -> dict:
        own = conn is None
        if own:
            conn = self._conn()
        try:
            u = conn.execute("SELECT * FROM usuarios WHERE id = ?", (usuario_id,)).fetchone()
            if not u:
                return {}
            base = {"id": u["id"], "nome": u["nome"], "email": u["email"], "tipo": u["tipo"]}
            if u["tipo"] == "aluno":
                p = conn.execute(
                    "SELECT * FROM perfis_aluno WHERE usuario_id = ?", (usuario_id,)
                ).fetchone()
                if p:
                    base.update(
                        {
                            "telefone": p["telefone"],
                            "serie_escolar": p["serie_escolar"],
                            "escola": p["escola"],
                            "preferencias": json.loads(p["preferencias"]) if p["preferencias"] else None,
                        }
                    )
            elif u["tipo"] == "professor":
                p = conn.execute(
                    "SELECT * FROM perfis_professor WHERE usuario_id = ?", (usuario_id,)
                ).fetchone()
                if p:
                    base.update(
                        {
                            "disciplina": p["disciplina"],
                            "bio": p["bio"],
                            "formacao": p["formacao"],
                            "valor_hora": p["valor_hora"],
                            "avaliacao_media": p["avaliacao_media"],
                            "telefone": p["telefone"],
                        }
                    )
            return base
        finally:
            if own:
                conn.close()

    def atualizar_perfil_aluno(self, usuario_id: int, **campos) -> None:
        allowed = {"nome", "email", "telefone", "serie_escolar", "escola", "preferencias"}
        campos = {k: v for k, v in campos.items() if k in allowed}
        with self._conn() as conn:
            if "nome" in campos or "email" in campos:
                sets, vals = [], []
                if "nome" in campos:
                    sets.append("nome = ?")
                    vals.append(campos.pop("nome"))
                if "email" in campos:
                    sets.append("email = ?")
                    vals.append(campos.pop("email"))
                vals.append(usuario_id)
                conn.execute(f"UPDATE usuarios SET {', '.join(sets)} WHERE id = ?", vals)
            if campos:
                if "preferencias" in campos and not isinstance(campos["preferencias"], str):
                    campos["preferencias"] = json.dumps(campos["preferencias"], ensure_ascii=False)
                sets = ", ".join(f"{k} = ?" for k in campos)
                vals = list(campos.values()) + [usuario_id]
                conn.execute(f"UPDATE perfis_aluno SET {sets} WHERE usuario_id = ?", vals)
            self._log_acao(conn.cursor(), usuario_id, "atualizar_perfil", "usuario", usuario_id, campos)
            conn.commit()

    def atualizar_perfil_professor(self, usuario_id: int, **campos) -> None:
        allowed = {"nome", "email", "disciplina", "bio", "formacao", "valor_hora", "telefone"}
        campos = {k: v for k, v in campos.items() if k in allowed}
        with self._conn() as conn:
            user_fields = {k: campos.pop(k) for k in ("nome", "email") if k in campos}
            if user_fields:
                sets = ", ".join(f"{k} = ?" for k in user_fields)
                vals = list(user_fields.values()) + [usuario_id]
                conn.execute(f"UPDATE usuarios SET {sets} WHERE id = ?", vals)
            if campos:
                sets = ", ".join(f"{k} = ?" for k in campos)
                vals = list(campos.values()) + [usuario_id]
                conn.execute(f"UPDATE perfis_professor SET {sets} WHERE usuario_id = ?", vals)
            self._log_acao(conn.cursor(), usuario_id, "atualizar_perfil", "usuario", usuario_id, {**user_fields, **campos})
            conn.commit()

    # ---------- Agendamentos ----------

    def solicitar_aula(
        self,
        aluno_id: int,
        professor_id: int,
        disciplina: str,
        data: str,
        horario: str,
        observacao: str | None = None,
        ip: str | None = None,
    ) -> int:
        with self._conn() as conn:
            cur = conn.cursor()
            conflito = cur.execute(
                """
                SELECT id FROM agendamentos
                WHERE professor_id = ? AND data = ? AND horario = ?
                  AND status IN ('pendente', 'confirmada')
                """,
                (professor_id, data, horario),
            ).fetchone()
            if conflito:
                raise ValueError("Horário já ocupado ou com solicitação pendente.")

            cur.execute(
                """
                INSERT INTO agendamentos
                    (aluno_id, professor_id, disciplina, data, horario, status, observacao)
                VALUES (?, ?, ?, ?, ?, 'pendente', ?)
                """,
                (aluno_id, professor_id, disciplina, data, horario, observacao),
            )
            ag_id = cur.lastrowid
            self._log_acao(
                cur, aluno_id, "solicitar_aula", "agendamento", ag_id,
                {"professor_id": professor_id, "disciplina": disciplina, "data": data, "horario": horario},
                ip,
            )
            conn.commit()
            return ag_id

    def responder_solicitacao(
        self,
        professor_id: int,
        agendamento_id: int,
        status: str,
        ip: str | None = None,
    ) -> None:
        if status not in ("confirmada", "recusada"):
            raise ValueError("Status deve ser 'confirmada' ou 'recusada'")
        with self._conn() as conn:
            cur = conn.cursor()
            row = cur.execute(
                "SELECT * FROM agendamentos WHERE id = ? AND professor_id = ?",
                (agendamento_id, professor_id),
            ).fetchone()
            if not row:
                raise ValueError("Solicitação não encontrada para este professor.")
            if row["status"] != "pendente":
                raise ValueError(f"Solicitação já está como '{row['status']}'.")
            agora = datetime.now().isoformat(timespec="seconds")
            cur.execute(
                "UPDATE agendamentos SET status = ?, respondido_em = ? WHERE id = ?",
                (status, agora, agendamento_id),
            )
            acao = "aceitar_aula" if status == "confirmada" else "recusar_aula"
            self._log_acao(cur, professor_id, acao, "agendamento", agendamento_id, {"status": status}, ip)
            conn.commit()

    def cancelar_aula(self, usuario_id: int, agendamento_id: int, ip: str | None = None) -> None:
        with self._conn() as conn:
            cur = conn.cursor()
            row = cur.execute("SELECT * FROM agendamentos WHERE id = ?", (agendamento_id,)).fetchone()
            if not row:
                raise ValueError("Agendamento não encontrado.")
            if row["aluno_id"] != usuario_id and row["professor_id"] != usuario_id:
                raise ValueError("Sem permissão para cancelar.")
            cur.execute(
                "UPDATE agendamentos SET status = 'cancelada' WHERE id = ?",
                (agendamento_id,),
            )
            self._log_acao(cur, usuario_id, "cancelar_aula", "agendamento", agendamento_id, None, ip)
            conn.commit()

    def listar_solicitacoes_professor(self, professor_id: int) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                """
                SELECT a.*, u.nome AS aluno_nome, u.email AS aluno_email
                FROM agendamentos a
                JOIN usuarios u ON u.id = a.aluno_id
                WHERE a.professor_id = ? AND a.status = 'pendente'
                ORDER BY a.data, a.horario
                """,
                (professor_id,),
            ).fetchall()
            return [dict(r) for r in rows]

    def listar_aulas_aluno(self, aluno_id: int, apenas_confirmadas: bool = False) -> list[dict]:
        with self._conn() as conn:
            sql = """
                SELECT a.*, u.nome AS professor_nome
                FROM agendamentos a
                JOIN usuarios u ON u.id = a.professor_id
                WHERE a.aluno_id = ? AND a.status != 'recusada'
            """
            if apenas_confirmadas:
                sql += " AND a.status = 'confirmada'"
            sql += " ORDER BY a.data, a.horario"
            rows = conn.execute(sql, (aluno_id,)).fetchall()
            return [dict(r) for r in rows]

    def listar_professores(self, disciplina: str | None = None) -> list[dict]:
        with self._conn() as conn:
            sql = """
                SELECT u.id, u.nome, u.email, p.disciplina, p.bio, p.avaliacao_media, p.valor_hora
                FROM usuarios u
                JOIN perfis_professor p ON p.usuario_id = u.id
                WHERE u.ativo = 1 AND u.tipo = 'professor'
            """
            params: list[Any] = []
            if disciplina:
                sql += " AND p.disciplina = ?"
                params.append(disciplina)
            sql += " ORDER BY u.nome"
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

    # ---------- Históricos ----------

    def listar_acessos(self, usuario_id: int | None = None, limite: int = 50) -> list[dict]:
        with self._conn() as conn:
            if usuario_id:
                rows = conn.execute(
                    "SELECT * FROM historico_acessos WHERE usuario_id = ? ORDER BY id DESC LIMIT ?",
                    (usuario_id, limite),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM historico_acessos ORDER BY id DESC LIMIT ?",
                    (limite,),
                ).fetchall()
            return [dict(r) for r in rows]

    def listar_acoes(self, usuario_id: int | None = None, limite: int = 50) -> list[dict]:
        with self._conn() as conn:
            if usuario_id:
                rows = conn.execute(
                    "SELECT * FROM historico_acoes WHERE usuario_id = ? ORDER BY id DESC LIMIT ?",
                    (usuario_id, limite),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM historico_acoes ORDER BY id DESC LIMIT ?",
                    (limite,),
                ).fetchall()
            return [dict(r) for r in rows]

    # ---------- helpers ----------

    def _log_acao(
        self,
        cur: sqlite3.Cursor,
        usuario_id: int | None,
        acao: str,
        entidade: str | None,
        entidade_id: int | None,
        detalhes: Any = None,
        ip: str | None = None,
    ) -> None:
        det = json.dumps(detalhes, ensure_ascii=False) if detalhes is not None else None
        cur.execute(
            """INSERT INTO historico_acoes
               (usuario_id, acao, entidade, entidade_id, detalhes, ip)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (usuario_id, acao, entidade, entidade_id, det, ip),
        )

    def listar_usuarios(self) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, nome, email, tipo, ativo, criado_em FROM usuarios ORDER BY id"
            ).fetchall()
            return [dict(r) for r in rows]


# ---------- CLI demo ----------

def _demo():
    db = Database()
    print("Usuários cadastrados:")
    for u in db.listar_usuarios():
        print(" ", u)

    print("\nLogin demo (gabriel@email.com / 123456):")
    sess = db.login("gabriel@email.com", "123456", ip="127.0.0.1")
    print(" ", {k: sess[k] for k in ("id", "nome", "tipo", "token")} if sess else "FALHOU")

    print("\nSolicitações do professor Gabriel:")
    if sess:
        sols = db.listar_solicitacoes_professor(sess["id"])
        for s in sols:
            print(" ", dict(s))

    print("\nÚltimos acessos:")
    for a in db.listar_acessos(limite=5):
        print(" ", dict(a))

    print("\nÚltimas ações:")
    for a in db.listar_acoes(limite=5):
        print(" ", dict(a))


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "demo"
    db = Database()
    if cmd == "demo":
        _demo()
    elif cmd == "listar-users":
        for u in db.listar_usuarios():
            print(u)
    elif cmd == "listar-profs":
        for p in db.listar_professores():
            print(p)
    else:
        print("Comandos: demo | listar-users | listar-profs")

-- Seed snapshot — Fora do Lápis
-- Senha demo de todas as contas: 123456
-- Gerado: 2026-09-25T13:17:30

-- disciplinas (4)
--   {'id': 1, 'nome': 'Matemática', 'descricao': 'Álgebra, geometria e muito mais.', 'ativa': 1, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'nome': 'Português', 'descricao': 'Gramática, literatura e redação.', 'ativa': 1, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 3, 'nome': 'Inglês', 'descricao': 'Conversação e preparação.', 'ativa': 1, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 4, 'nome': 'Física', 'descricao': 'Teoria e resolução de exercícios.', 'ativa': 1, 'criado_em': '2026-09-25 13:17:30'}

-- app_config (5)
--   {'chave': 'app_nome', 'valor': 'Fora do Lápis', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'chave': 'app_versao', 'valor': '1.1.0', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'chave': 'max_tentativas_login', 'valor': '5', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'chave': 'sessao_duracao_horas', 'valor': '24', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'chave': 'timezone', 'valor': 'America/Sao_Paulo', 'atualizado_em': '2026-09-25 13:17:30'}

-- usuarios (4)
--   {'id': 1, 'nome': 'Gabriel Santos', 'email': 'gabriel@email.com', 'tipo': 'professor', 'ativo': 1, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'nome': 'Mariana Oliveira', 'email': 'mariana@email.com', 'tipo': 'professor', 'ativo': 1, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 3, 'nome': 'Lucas Almeida', 'email': 'lucas@email.com', 'tipo': 'professor', 'ativo': 1, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 4, 'nome': 'Ana Silva', 'email': 'ana@email.com', 'tipo': 'aluno', 'ativo': 1, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}

-- credenciais (4)
--   {'id': 1, 'usuario_id': 1, 'senha_hash': '8591fbf5e6839951623911d60f4e70343548b764f1baa77f12a53225ee0f2990', 'algoritmo': 'sha256-salt', 'tentativas_falha': 0, 'bloqueado_ate': None, 'ultimo_login': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'usuario_id': 2, 'senha_hash': '8591fbf5e6839951623911d60f4e70343548b764f1baa77f12a53225ee0f2990', 'algoritmo': 'sha256-salt', 'tentativas_falha': 0, 'bloqueado_ate': None, 'ultimo_login': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 3, 'usuario_id': 3, 'senha_hash': '8591fbf5e6839951623911d60f4e70343548b764f1baa77f12a53225ee0f2990', 'algoritmo': 'sha256-salt', 'tentativas_falha': 0, 'bloqueado_ate': None, 'ultimo_login': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 4, 'usuario_id': 4, 'senha_hash': '8591fbf5e6839951623911d60f4e70343548b764f1baa77f12a53225ee0f2990', 'algoritmo': 'sha256-salt', 'tentativas_falha': 0, 'bloqueado_ate': None, 'ultimo_login': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}

-- perfis_aluno (1)
--   {'id': 1, 'usuario_id': 4, 'telefone': None, 'serie_escolar': '3º ano EM', 'escola': 'Colégio Exemplo', 'preferencias': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}

-- perfis_professor (3)
--   {'id': 1, 'usuario_id': 1, 'disciplina': 'Matemática', 'bio': 'Especialista em álgebra e geometria.', 'formacao': None, 'valor_hora': None, 'avaliacao_media': 5.0, 'telefone': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'usuario_id': 2, 'disciplina': 'Português', 'bio': 'Gramática, literatura e redação.', 'formacao': None, 'valor_hora': None, 'avaliacao_media': 5.0, 'telefone': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}
--   {'id': 3, 'usuario_id': 3, 'disciplina': 'Inglês', 'bio': 'Conversação e preparação para exames.', 'formacao': None, 'valor_hora': None, 'avaliacao_media': 5.0, 'telefone': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}

-- agendamentos (1)
--   {'id': 1, 'aluno_id': 4, 'professor_id': 1, 'disciplina': 'Matemática', 'data': '2026-09-27', 'horario': '14:00', 'status': 'pendente', 'observacao': 'Revisão de equações', 'respondido_em': None, 'criado_em': '2026-09-25 13:17:30', 'atualizado_em': '2026-09-25 13:17:30'}

-- historico_acessos (2)
--   {'id': 1, 'usuario_id': 1, 'email_tentativa': 'gabriel@email.com', 'sucesso': 1, 'ip': '127.0.0.1', 'user_agent': None, 'mensagem': 'Login bem-sucedido', 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'usuario_id': None, 'email_tentativa': 'inexistente@email.com', 'sucesso': 0, 'ip': '127.0.0.1', 'user_agent': None, 'mensagem': 'Conta não encontrada', 'criado_em': '2026-09-25 13:17:30'}

-- historico_acoes (5)
--   {'id': 1, 'usuario_id': 1, 'acao': 'cadastro', 'entidade': 'usuario', 'entidade_id': 1, 'detalhes': '{"tipo": "professor", "disciplina": "Matemática"}', 'ip': None, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 2, 'usuario_id': 2, 'acao': 'cadastro', 'entidade': 'usuario', 'entidade_id': 2, 'detalhes': '{"tipo": "professor", "disciplina": "Português"}', 'ip': None, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 3, 'usuario_id': 3, 'acao': 'cadastro', 'entidade': 'usuario', 'entidade_id': 3, 'detalhes': '{"tipo": "professor", "disciplina": "Inglês"}', 'ip': None, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 4, 'usuario_id': 4, 'acao': 'cadastro', 'entidade': 'usuario', 'entidade_id': 4, 'detalhes': '{"tipo": "aluno"}', 'ip': None, 'criado_em': '2026-09-25 13:17:30'}
--   {'id': 5, 'usuario_id': 4, 'acao': 'solicitar_aula', 'entidade': 'agendamento', 'entidade_id': 1, 'detalhes': '{"disciplina": "Matemática", "professor_id": 1, "data": "2026-09-27", "horario": "14:00"}', 'ip': None, 'criado_em': '2026-09-25 13:17:30'}

/*
========================================
FORA DO LÁPIS - SISTEMA DE AGENDAMENTO
JavaScript principal
========================================
*/

const DISCIPLINAS_PADRAO = ["Matemática", "Português", "Inglês", "Física"];

/* ---------- Storage helpers ---------- */

function getProfessores() {
    const salvos = JSON.parse(localStorage.getItem("professores") || "[]");
    if (salvos.length === 0) {
        return [
            { id: 1, nome: "Gabriel Santos", email: "gabriel@email.com", disciplina: "Matemática", tipo: "professor", bio: "Especialista em álgebra e geometria." },
            { id: 2, nome: "Mariana Oliveira", email: "mariana@email.com", disciplina: "Português", tipo: "professor", bio: "Gramática, literatura e redação." },
            { id: 3, nome: "Lucas Almeida", email: "lucas@email.com", disciplina: "Inglês", tipo: "professor", bio: "Conversação e preparação para exames." }
        ];
    }
    return salvos;
}

function setProfessores(lista) {
    localStorage.setItem("professores", JSON.stringify(lista));
}

function getAlunos() {
    return JSON.parse(localStorage.getItem("alunos") || "[]");
}

function setAlunos(lista) {
    localStorage.setItem("alunos", JSON.stringify(lista));
}

function getAgendamentos() {
    return JSON.parse(localStorage.getItem("agendamentos") || "[]");
}

function setAgendamentos(lista) {
    localStorage.setItem("agendamentos", JSON.stringify(lista));
}

function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("usuarioLogado") || "null");
}

function setUsuarioLogado(usuario) {
    if (usuario) {
        localStorage.setItem("usuarioLogado", JSON.stringify(usuario));
    } else {
        localStorage.removeItem("usuarioLogado");
    }
}


/* ---------- Status de agendamento ---------- */

function statusAgendamento(a) {
    return a.status || "confirmada"; // dados antigos sem status = já confirmados
}

function isConfirmada(a) {
    return statusAgendamento(a) === "confirmada";
}

function isPendente(a) {
    return statusAgendamento(a) === "pendente";
}


/* ---------- Menu mobile ---------- */

function toggleMenu() {
    const menu = document.getElementById("menu");
    if (!menu) return;
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
        menu.style.flexDirection = "column";
        menu.style.position = "absolute";
        menu.style.top = "76px";
        menu.style.left = "0";
        menu.style.right = "0";
        menu.style.padding = "20px";
        menu.style.background = "white";
        menu.style.borderBottom = "1px solid #eee";
        menu.style.zIndex = "999";
    }
}

/* ---------- Modais ---------- */

function abrirLogin() {
    const el = document.getElementById("loginModal");
    if (el) el.classList.add("active");
}

function fecharModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove("active");
}

function abrirTipoCadastro() {
    const el = document.getElementById("tipoCadastroModal");
    if (el) el.classList.add("active");
}

function escolherTipoCadastro(tipo) {
    fecharModal("tipoCadastroModal");
    abrirCadastro(tipo);
}

function abrirCadastro(tipo) {
    const modal = document.getElementById("registerModal");
    if (!modal) return;

    const titulo = document.getElementById("registerTitle");
    const desc = document.getElementById("registerDesc");
    const disciplinaGroup = document.getElementById("disciplinaGroup");
    const tipoInput = document.getElementById("registerTipo");
    const customGroup = document.getElementById("disciplinaCustomGroup");

    if (tipo === "professor") {
        if (titulo) titulo.textContent = "Cadastro de Professor";
        if (desc) desc.textContent = "Crie sua conta e defina a disciplina que você ensina.";
        if (disciplinaGroup) disciplinaGroup.style.display = "flex";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = true;
        if (tipoInput) tipoInput.value = "professor";
    } else {
        if (titulo) titulo.textContent = "Cadastro de Aluno";
        if (desc) desc.textContent = "Crie sua conta para começar a agendar aulas.";
        if (disciplinaGroup) disciplinaGroup.style.display = "none";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = false;
        if (customGroup) customGroup.style.display = "none";
        if (tipoInput) tipoInput.value = "aluno";
    }

    modal.classList.add("active");
}

function trocarParaCadastro() {
    fecharModal("loginModal");
    abrirTipoCadastro();
}

function trocarParaLogin() {
    fecharModal("registerModal");
    abrirLogin();
}

function onDisciplinaChange() {
    const select = document.getElementById("registerDisciplina");
    const customGroup = document.getElementById("disciplinaCustomGroup");
    const customInput = document.getElementById("registerDisciplinaCustom");
    if (!select || !customGroup) return;

    if (select.value === "__outra__") {
        customGroup.style.display = "flex";
        if (customInput) customInput.required = true;
    } else {
        customGroup.style.display = "none";
        if (customInput) customInput.required = false;
    }
}

/* ---------- Navegação ---------- */

function irParaAgendamento() {
    const el = document.getElementById("agendar");
    if (el) el.scrollIntoView({ behavior: "smooth" });
}

function selecionarDisciplina(disciplina) {
    const select = document.getElementById("discipline");
    if (select) {
        select.value = disciplina;
        atualizarProfessoresPorDisciplina();
    }
    irParaAgendamento();
}

function selecionarProfessor(professor) {
    const select = document.getElementById("teacher");
    const discSelect = document.getElementById("discipline");
    const prof = getProfessores().find(function (p) { return p.nome === professor; });
    if (prof && discSelect) {
        discSelect.value = prof.disciplina;
        atualizarSelectProfessores();
    }
    if (select) select.value = professor;
    irParaAgendamento();
}

/* ---------- Toast ---------- */

function mostrarToast(mensagem) {
    const toast = document.getElementById("toast");
    const message = document.getElementById("toastMessage");
    if (!toast || !message) return;
    message.textContent = mensagem;
    toast.classList.add("active");
    setTimeout(function () {
        toast.classList.remove("active");
    }, 3500);
}

/* ---------- Selects ---------- */

function atualizarSelectProfessores() {
    const select = document.getElementById("teacher");
    if (!select) return;

    const disciplina = (document.getElementById("discipline") || {}).value || "";
    const professores = getProfessores();

    select.innerHTML = '<option value="">Selecione um professor</option>';

    const filtrados = disciplina
        ? professores.filter(function (p) { return p.disciplina === disciplina; })
        : professores;

    filtrados.forEach(function (p) {
        const opt = document.createElement("option");
        opt.value = p.nome;
        opt.textContent = p.nome + " (" + p.disciplina + ")";
        select.appendChild(opt);
    });
}

function atualizarProfessoresPorDisciplina() {
    atualizarSelectProfessores();
}

function atualizarSelectDisciplinas() {
    const select = document.getElementById("discipline");
    if (!select) return;

    const professores = getProfessores();
    const set = {};
    DISCIPLINAS_PADRAO.forEach(function (d) { set[d] = true; });
    professores.forEach(function (p) {
        if (p.disciplina) set[p.disciplina] = true;
    });

    const disciplinas = Object.keys(set).sort();
    const valorAtual = select.value;

    select.innerHTML = '<option value="">Selecione uma disciplina</option>';
    disciplinas.forEach(function (d) {
        const opt = document.createElement("option");
        opt.value = d;
        opt.textContent = d;
        select.appendChild(opt);
    });
    if (valorAtual) select.value = valorAtual;
}

/* ---------- Lista de professores (home) ---------- */

function renderizarProfessores() {
    const container = document.getElementById("teachersList");
    if (!container) return;

    const professores = getProfessores();
    const cores = ["purple-bg", "blue-bg", "green-bg", "orange-bg"];

    container.innerHTML = "";

    professores.forEach(function (p, i) {
        const cor = cores[i % cores.length];
        const card = document.createElement("div");
        card.className = "teacher-card";
        const nomeEsc = String(p.nome).replace(/'/g, "\\'");
        card.innerHTML =
            '<div class="teacher-image ' + cor + '"><i class="fa-solid fa-user"></i></div>' +
            '<div class="teacher-info">' +
            "<h3>" + p.nome + "</h3>" +
            "<span>" + (p.disciplina || "") + "</span>" +
            '<div class="rating">★★★★★ <small>5.0</small></div>' +
            '<button type="button" onclick="selecionarProfessor(\'' + nomeEsc + '\')" class="teacher-button">Agendar</button>' +
            "</div>";
        container.appendChild(card);
    });
}

/* ---------- Calendário dinâmico ---------- */

var mesAtual = new Date().getMonth();
var anoAtual = new Date().getFullYear();

var NOMES_MES = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

function formatarDataISO(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return y + "-" + m + "-" + day;
}

function renderizarCalendario() {
    var mesLabel = document.getElementById("calendarMonth");
    var daysContainer = document.getElementById("calendarDays");
    var weekContainer = document.getElementById("calendarWeek");
    if (!mesLabel || !daysContainer) return;

    mesLabel.textContent = NOMES_MES[mesAtual] + " " + anoAtual;

    if (weekContainer) {
        weekContainer.innerHTML =
            "<span>SEG</span><span>TER</span><span>QUA</span><span>QUI</span><span>SEX</span>";
    }

    var totalDias = new Date(anoAtual, mesAtual + 1, 0).getDate();
    var agendamentos = getAgendamentos();
    var usuario = getUsuarioLogado();
    // Só marca no calendário as aulas do usuário logado (aluno: suas confirmadas; professor: confirmadas com ele)
    if (usuario) {
        if (usuario.tipo === "aluno") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && (a.email === usuario.email || a.nome === usuario.nome);
            });
        } else if (usuario.tipo === "professor") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && a.professor === usuario.nome;
            });
        }
    } else {
        // Sem login: não marca aulas de ninguém (privacidade)
        agendamentos = [];
    }
    var diasComAula = {};

    agendamentos.forEach(function (a) {
        var parts = a.data.split("-").map(Number);
        var y = parts[0], m = parts[1], d = parts[2];
        if (y === anoAtual && m - 1 === mesAtual) {
            if (!diasComAula[d]) diasComAula[d] = [];
            diasComAula[d].push(a);
        }
    });

    var diasParaMostrar = [];
    var d = 1;
    while (diasParaMostrar.length < 5 && d <= totalDias) {
        var data = new Date(anoAtual, mesAtual, d);
        var ds = data.getDay();
        if (ds >= 1 && ds <= 5) diasParaMostrar.push(d);
        d++;
    }
    while (diasParaMostrar.length < 5 && d <= totalDias) {
        var data2 = new Date(anoAtual, mesAtual, d);
        var ds2 = data2.getDay();
        if (ds2 >= 1 && ds2 <= 5) diasParaMostrar.push(d);
        d++;
    }

    daysContainer.innerHTML = "";
    var hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    var hojeStr = formatarDataISO(hoje);

    diasParaMostrar.forEach(function (dia) {
        var span = document.createElement("span");
        span.textContent = dia;
        var dataStr = formatarDataISO(new Date(anoAtual, mesAtual, dia));

        if (diasComAula[dia]) {
            span.classList.add("has-booking");
            span.title = diasComAula[dia]
                .map(function (a) { return a.disciplina + " " + a.horario; })
                .join(", ");
        }
        if (dataStr === hojeStr) span.classList.add("active");

        span.addEventListener("click", function () {
            var spans = document.querySelectorAll("#calendarDays span");
            for (var i = 0; i < spans.length; i++) spans[i].classList.remove("active");
            span.classList.add("active");
            mostrarProximoAgendamento(dataStr);
        });

        daysContainer.appendChild(span);
    });

    mostrarProximoAgendamento();
}

function mostrarProximoAgendamento(dataFiltro) {
    var appointmentEl = document.getElementById("nextAppointment");
    var headerTitle = document.getElementById("dashboardSubject");
    var headerSmall = document.getElementById("dashboardLabel");
    if (!appointmentEl) return;

    var agora = new Date();
    var usuario = getUsuarioLogado();
    var base = getAgendamentos().filter(function (a) {
        if (!isConfirmada(a)) return false;
        if (!usuario) return false;
        if (usuario.tipo === "aluno") {
            return a.email === usuario.email || a.nome === usuario.nome;
        }
        if (usuario.tipo === "professor") {
            return a.professor === usuario.nome;
        }
        return false;
    });
    var lista = base
        .map(function (a) {
            return Object.assign({}, a, {
                datetime: new Date(a.data + "T" + a.horario + ":00")
            });
        })
        .filter(function (a) { return a.datetime >= agora; })
        .sort(function (a, b) { return a.datetime - b.datetime; });

    if (dataFiltro) {
        lista = lista.filter(function (a) { return a.data === dataFiltro; });
    }

    if (lista.length === 0) {
        if (headerSmall) headerSmall.textContent = "Próxima aula";
        if (headerTitle) headerTitle.textContent = "Nenhuma";
        appointmentEl.innerHTML =
            '<div class="appointment-icon"><i class="fa-solid fa-calendar"></i></div>' +
            "<div><strong>Sem agendamentos</strong><small>Agende sua próxima aula</small></div>" +
            "<strong>--</strong>";
        return;
    }

    var prox = lista[0];
    if (headerSmall) headerSmall.textContent = "Próxima aula";
    if (headerTitle) headerTitle.textContent = prox.disciplina;

    appointmentEl.innerHTML =
        '<div class="appointment-icon"><i class="fa-solid fa-calculator"></i></div>' +
        "<div><strong>" + prox.disciplina + "</strong><small>Prof. " + prox.professor + "</small></div>" +
        "<strong>" + prox.horario + "</strong>";
}

function mudarMes(delta) {
    mesAtual += delta;
    if (mesAtual > 11) {
        mesAtual = 0;
        anoAtual++;
    } else if (mesAtual < 0) {
        mesAtual = 11;
        anoAtual--;
    }
    renderizarCalendario();
}

/* ---------- UI usuário logado ---------- */

function atualizarUIUsuario() {
    var usuario = getUsuarioLogado();
    var navButtons = document.querySelector(".nav-buttons");
    if (!navButtons) return;

    // Atualiza menu principal: aba de solicitações só para professor logado
    var menu = document.getElementById("menu");
    if (menu) {
        var linksBase =
            '<a href="index.html">Início</a>' +
            '<a href="index.html#disciplinas">Disciplinas</a>' +
            '<a href="index.html#professores">Professores</a>' +
            '<a href="index.html#agendar">Agendar</a>';
        if (usuario && usuario.tipo === "professor") {
            linksBase +=
                '<a href="perfil-professor.html#secao-solicitacoes" class="nav-solicitacoes">' +
                '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
        } else if (usuario && usuario.tipo === "aluno") {
            linksBase +=
                '<a href="perfil-aluno.html" class="nav-minhas-aulas">' +
                '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
        }
        // Na home os hrefs originais são âncoras; preserva se estiver na home
        var page = document.body.getAttribute("data-page") || "";
        if (page === "home") {
            linksBase =
                '<a href="#inicio">Início</a>' +
                '<a href="#disciplinas">Disciplinas</a>' +
                '<a href="#professores">Professores</a>' +
                '<a href="#agendar">Agendar</a>';
            if (usuario && usuario.tipo === "professor") {
                linksBase +=
                    '<a href="perfil-professor.html#secao-solicitacoes" class="nav-solicitacoes">' +
                    '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
            } else if (usuario && usuario.tipo === "aluno") {
                linksBase +=
                    '<a href="perfil-aluno.html" class="nav-minhas-aulas">' +
                    '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
            }
        }
        menu.innerHTML = linksBase;
    }

    if (usuario) {
        var perfilHref = usuario.tipo === "professor" ? "perfil-professor.html" : "perfil-aluno.html";
        var tipoLabel = usuario.tipo === "professor" ? ' <small class="role-tag">(Prof.)</small>' : "";
        var extraBtn = "";
        if (usuario.tipo === "professor") {
            extraBtn =
                '<a href="perfil-professor.html#secao-solicitacoes" class="btn-outline btn-sm btn-solicitacoes">' +
                '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
        } else {
            extraBtn =
                '<a href="perfil-aluno.html" class="btn-outline btn-sm">' +
                '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
        }
        navButtons.innerHTML =
            '<a href="' + perfilHref + '" class="user-greeting">' +
            "Olá, <strong>" + usuario.nome.split(" ")[0] + "</strong>" + tipoLabel +
            "</a>" +
            extraBtn +
            '<a href="' + perfilHref + '" class="btn-outline btn-sm">Meu perfil</a>' +
            '<button type="button" class="btn-outline" onclick="logout()">Sair</button>';

        // Prefill formulário de agendamento se for aluno
        if (usuario.tipo === "aluno") {
            var sn = document.getElementById("studentName");
            var se = document.getElementById("studentEmail");
            if (sn && !sn.value) sn.value = usuario.nome;
            if (se && !se.value) se.value = usuario.email;
        }
    } else {
        navButtons.innerHTML =
            '<button type="button" class="btn-outline" onclick="abrirLogin()">Entrar</button>' +
            '<button type="button" class="btn-primary" onclick="abrirTipoCadastro()">Criar conta</button>';
    }
}

function logout() {
    setUsuarioLogado(null);
    atualizarUIUsuario();
    mostrarToast("Você saiu da conta.");
    // Se estiver em página de perfil, redireciona
    if (window.location.pathname.indexOf("perfil-") !== -1) {
        window.location.href = "index.html";
    }
}

function exigirLogin(tiposPermitidos) {
    var usuario = getUsuarioLogado();
    if (!usuario) {
        window.location.href = "index.html";
        return null;
    }
    if (tiposPermitidos && tiposPermitidos.indexOf(usuario.tipo) === -1) {
        var dest = usuario.tipo === "professor" ? "perfil-professor.html" : "perfil-aluno.html";
        window.location.href = dest;
        return null;
    }
    return usuario;
}

/* ---------- Eventos de formulários (home) ---------- */

function initHomeForms() {
    var bookingForm = document.getElementById("bookingForm");
    if (bookingForm) {
        bookingForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var usuario = getUsuarioLogado();
            if (!usuario) {
                mostrarToast("Faça login como aluno para solicitar uma aula.");
                abrirLogin();
                return;
            }
            if (usuario.tipo !== "aluno") {
                mostrarToast("Somente alunos podem solicitar agendamento.");
                return;
            }

            var disciplina = document.getElementById("discipline").value;
            var professor = document.getElementById("teacher").value;
            var data = document.getElementById("date").value;
            var horario = document.getElementById("time").value;
            var nome = (document.getElementById("studentName").value || "").trim() || usuario.nome;
            var email = (document.getElementById("studentEmail").value || "").trim() || usuario.email;

            if (!disciplina || !professor || !data || !horario || !nome || !email) {
                mostrarToast("Preencha todos os campos.");
                return;
            }

            var agendamentos = getAgendamentos();
            // Conflito só com confirmadas ou pendentes do mesmo professor/horário
            var conflito = agendamentos.find(function (a) {
                return a.professor === professor && a.data === data && a.horario === horario
                    && statusAgendamento(a) !== "recusada";
            });
            if (conflito) {
                mostrarToast("Horário já ocupado ou com solicitação pendente para este professor.");
                return;
            }

            agendamentos.push({
                id: Date.now(),
                disciplina: disciplina,
                professor: professor,
                data: data,
                horario: horario,
                nome: nome,
                email: email,
                status: "pendente"
            });
            setAgendamentos(agendamentos);

            mostrarToast("Solicitação enviada! Aguarde a confirmação do professor.");
            bookingForm.reset();
            // mantém nome/email do aluno logado
            document.getElementById("studentName").value = usuario.nome;
            document.getElementById("studentEmail").value = usuario.email;
            renderizarCalendario();
            atualizarSelectProfessores();
        });
    }

    var loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();
            var email = document.getElementById("loginEmail").value.trim();
            var senha = document.getElementById("loginPassword").value;

            if (!email || !senha) {
                mostrarToast("Preencha e-mail e senha.");
                return;
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var usuario = professores.find(function (p) { return p.email === email; });
            if (!usuario) {
                usuario = alunos.find(function (a) { return a.email === email; });
            }

            if (!usuario) {
                mostrarToast("Conta não encontrada. Crie uma conta primeiro.");
                return;
            }

            // Demo: não valida senha rigidamente
            setUsuarioLogado({
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                tipo: usuario.tipo,
                disciplina: usuario.disciplina || undefined,
                bio: usuario.bio || ""
            });
            atualizarUIUsuario();
            mostrarToast("Login realizado! Olá, " + usuario.nome);
            fecharModal("loginModal");
            loginForm.reset();
        });
    }

    var registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var nome = document.getElementById("registerName").value.trim();
            var email = document.getElementById("registerEmail").value.trim();
            var senha = document.getElementById("registerPassword").value;
            var tipo = document.getElementById("registerTipo").value;
            var disciplinaSelect = document.getElementById("registerDisciplina");
            var disciplinaCustom = document.getElementById("registerDisciplinaCustom");

            if (!nome || !email || !senha) {
                mostrarToast("Preencha todos os campos obrigatórios.");
                return;
            }

            var disciplina = "";
            if (tipo === "professor") {
                disciplina = disciplinaSelect ? disciplinaSelect.value : "";
                if (disciplina === "__outra__") {
                    disciplina = disciplinaCustom ? disciplinaCustom.value.trim() : "";
                }
                if (!disciplina) {
                    mostrarToast("Selecione ou digite a disciplina.");
                    return;
                }
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var emails = professores.map(function (p) { return p.email; })
                .concat(alunos.map(function (a) { return a.email; }));

            if (emails.indexOf(email) !== -1) {
                mostrarToast("Este e-mail já está cadastrado.");
                return;
            }

            var novoId = Date.now();

            if (tipo === "professor") {
                var listaP = JSON.parse(localStorage.getItem("professores") || "[]");
                if (listaP.length === 0) {
                    listaP = getProfessores().slice();
                }
                var novoP = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    disciplina: disciplina,
                    tipo: "professor",
                    bio: "",
                    senha: senha
                };
                listaP.push(novoP);
                setProfessores(listaP);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "professor",
                    disciplina: disciplina,
                    bio: ""
                });
                mostrarToast("Conta de professor criada!");
            } else {
                var listaA = getAlunos();
                var novoA = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno",
                    senha: senha
                };
                listaA.push(novoA);
                setAlunos(listaA);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno"
                });
                mostrarToast("Conta de aluno criada!");
            }

            fecharModal("registerModal");
            registerForm.reset();
            var customG = document.getElementById("disciplinaCustomGroup");
            if (customG) customG.style.display = "none";
            atualizarUIUsuario();
            renderizarProfessores();
            atualizarSelectProfessores();
            atualizarSelectDisciplinas();
        });
    }

    var discSelect = document.getElementById("discipline");
    if (discSelect) {
        discSelect.addEventListener("change", atualizarProfessoresPorDisciplina);
    }

    var dateInput = document.getElementById("date");
    if (dateInput) {
        dateInput.min = new Date().toISOString().split("T")[0];
    }

    document.querySelectorAll(".modal").forEach(function (modal) {
        modal.addEventListener("click", function (event) {
            if (event.target === modal) modal.classList.remove("active");
        });
    });
}

/* ---------- Página de perfil do ALUNO ---------- */

function initPerfilAluno() {
    var usuario = exigirLogin(["aluno"]);
    if (!usuario) return;

    atualizarUIUsuario();

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var listaEl = document.getElementById("minhasAulas");

    if (nomeEl) nomeEl.textContent = usuario.nome;
    if (emailEl) emailEl.textContent = usuario.email;
    if (avatarEl) avatarEl.textContent = (usuario.nome || "A").charAt(0).toUpperCase();

    var todos = getAgendamentos().filter(function (a) {
        return (a.email === usuario.email || a.nome === usuario.nome)
            && statusAgendamento(a) !== "recusada";
    });

    var agora = new Date();
    var futuros = todos.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var confirmadasFuturas = futuros.filter(isConfirmada);

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(confirmadasFuturas.length);

    if (listaEl) {
        if (futuros.length === 0) {
            listaEl.innerHTML =
                '<div class="empty-state">' +
                '<i class="fa-solid fa-calendar-xmark"></i>' +
                "<p>Você ainda não tem aulas agendadas.</p>" +
                '<a href="index.html#agendar" class="btn-primary">Agendar aula</a>' +
                "</div>";
        } else {
            listaEl.innerHTML = futuros.map(function (a) {
                var st = statusAgendamento(a);
                var badge = st === "pendente"
                    ? '<span class="status-badge pendente">Aguardando professor</span>'
                    : '<span class="status-badge confirmada">Confirmada</span>';
                var btn = st === "pendente"
                    ? '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar pedido</button>'
                    : '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar</button>';
                return (
                    '<div class="aula-card">' +
                    '<div class="aula-icon"><i class="fa-solid fa-book-open"></i></div>' +
                    "<div class=\"aula-info\">" +
                    "<strong>" + a.disciplina + "</strong>" +
                    "<span>Prof. " + a.professor + "</span>" +
                    badge +
                    "</div>" +
                    '<div class="aula-meta">' +
                    "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                    "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                    "</div>" +
                    btn +
                    "</div>"
                );
            }).join("");
        }
    }

    // Formulário editar perfil
    var editForm = document.getElementById("editPerfilForm");
    if (editForm) {
        document.getElementById("editNome").value = usuario.nome;
        document.getElementById("editEmail").value = usuario.email;

        editForm.addEventListener("submit", function (e) {
            e.preventDefault();
            var novoNome = document.getElementById("editNome").value.trim();
            var novoEmail = document.getElementById("editEmail").value.trim();
            if (!novoNome || !novoEmail) {
                mostrarToast("Preencha nome e e-mail.");
                return;
            }

            var alunos = getAlunos();
            var idx = alunos.findIndex(function (a) { return a.email === usuario.email; });
            if (idx !== -1) {
                alunos[idx].nome = novoNome;
                alunos[idx].email = novoEmail;
                setAlunos(alunos);
            }

            usuario.nome = novoNome;
            usuario.email = novoEmail;
            setUsuarioLogado(usuario);

            if (nomeEl) nomeEl.textContent = novoNome;
            if (emailEl) emailEl.textContent = novoEmail;
            if (avatarEl) avatarEl.textContent = novoNome.charAt(0).toUpperCase();
            atualizarUIUsuario();
            mostrarToast("Perfil atualizado!");
            fecharModal("editPerfilModal");
        });
    }
}

function cancelarAula(id) {
    var lista = getAgendamentos().filter(function (a) { return a.id !== id; });
    setAgendamentos(lista);
    mostrarToast("Aula cancelada.");
    initPerfilAluno();
}

function responderSolicitacao(id, novoStatus) {
    var usuario = getUsuarioLogado();
    if (!usuario || usuario.tipo !== "professor") {
        mostrarToast("Apenas o professor pode responder solicitações.");
        return;
    }
    var lista = getAgendamentos();
    var idx = lista.findIndex(function (a) { return a.id === id; });
    if (idx === -1) {
        mostrarToast("Solicitação não encontrada.");
        return;
    }
    if (lista[idx].professor !== usuario.nome) {
        mostrarToast("Esta solicitação não é sua.");
        return;
    }
    lista[idx].status = novoStatus;
    setAgendamentos(lista);
    if (novoStatus === "confirmada") {
        mostrarToast("Aula confirmada! O aluno verá na área dele.");
    } else {
        mostrarToast("Solicitação recusada.");
    }
    initPerfilProfessor();
}

function formatarDataBR(iso) {
    var parts = iso.split("-");
    if (parts.length !== 3) return iso;
    return parts[2] + "/" + parts[1] + "/" + parts[0];
}

/* ---------- Página de perfil do PROFESSOR ---------- */

function initPerfilProfessor() {
    var usuario = exigirLogin(["professor"]);
    if (!usuario) return;

    atualizarUIUsuario();

    // Atualiza dados frescos do storage
    var profs = getProfessores();
    var atual = profs.find(function (p) { return p.email === usuario.email; });
    if (atual) {
        usuario.disciplina = atual.disciplina;
        usuario.bio = atual.bio || "";
        usuario.nome = atual.nome;
        setUsuarioLogado(usuario);
    }

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var discEl = document.getElementById("perfilDisciplina");
    var bioEl = document.getElementById("perfilBio");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var alunosEl = document.getElementById("statAlunos");
    var listaEl = document.getElementById("minhasAulas");

    if (nomeEl) nomeEl.textContent = usuario.nome;
    if (emailEl) emailEl.textContent = usuario.email;
    if (discEl) discEl.textContent = usuario.disciplina || "—";
    if (bioEl) bioEl.textContent = usuario.bio || "Nenhuma bio definida.";
    if (avatarEl) avatarEl.textContent = (usuario.nome || "P").charAt(0).toUpperCase();

    var todos = getAgendamentos().filter(function (a) {
        return a.professor === usuario.nome;
    });

    var agora = new Date();
    var pendentes = todos.filter(function (a) {
        return isPendente(a) && new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var futuros = confirmadas.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var alunosUnicos = {};
    confirmadas.forEach(function (a) { alunosUnicos[a.email] = true; });

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(futuros.length);
    if (alunosEl) alunosEl.textContent = String(Object.keys(alunosUnicos).length);

    // Lista de solicitações pendentes (só no login do professor)
    var listaSol = document.getElementById("listaSolicitacoes");
    if (listaSol) {
        if (pendentes.length === 0) {
            listaSol.innerHTML =
                '<div class="empty-state">' +
                '<i class="fa-solid fa-inbox"></i>' +
                "<p>Nenhuma solicitação pendente no momento.</p>" +
                "</div>";
        } else {
            listaSol.innerHTML = pendentes.map(function (a) {
                return (
                    '<div class="aula-card solicitacao-card">' +
                    '<div class="aula-icon pending"><i class="fa-solid fa-clock"></i></div>' +
                    "<div class=\"aula-info\">" +
                    "<strong>" + a.disciplina + "</strong>" +
                    "<span>Aluno: " + a.nome + "</span>" +
                    "<small>" + a.email + "</small>" +
                    '<span class="status-badge pendente">Pendente</span>' +
                    "</div>" +
                    '<div class="aula-meta">' +
                    "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                    "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                    "</div>" +
                    '<div class="solicitacao-actions">' +
                    '<button type="button" class="btn-accept" onclick="responderSolicitacao(' + a.id + ', \'confirmada\')">Aceitar</button>' +
                    '<button type="button" class="btn-reject" onclick="responderSolicitacao(' + a.id + ', \'recusada\')">Recusar</button>' +
                    "</div>" +
                    "</div>"
                );
            }).join("");
        }
    }

    if (listaEl) {
        if (futuros.length === 0) {
            listaEl.innerHTML =
                '<div class="empty-state">' +
                '<i class="fa-solid fa-calendar-xmark"></i>' +
                "<p>Nenhuma aula confirmada com você ainda.</p>" +
                "</div>";
        } else {
            listaEl.innerHTML = futuros.map(function (a) {
                return (
                    '<div class="aula-card">' +
                    '<div class="aula-icon teacher"><i class="fa-solid fa-user-graduate"></i></div>' +
                    "<div class=\"aula-info\">" +
                    "<strong>" + a.disciplina + "</strong>" +
                    "<span>Aluno: " + a.nome + "</span>" +
                    "<small>" + a.email + "</small>" +
                    '<span class="status-badge confirmada">Confirmada</span>' +
                    "</div>" +
                    '<div class="aula-meta">' +
                    "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                    "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                    "</div>" +
                    "</div>"
                );
            }).join("");
        }
    }

    // Formulário editar perfil professor
    var editForm = document.getElementById("editPerfilForm");
    if (editForm) {
        document.getElementById("editNome").value = usuario.nome;
        document.getElementById("editEmail").value = usuario.email;
        document.getElementById("editDisciplina").value = usuario.disciplina || "";
        document.getElementById("editBio").value = usuario.bio || "";

        editForm.addEventListener("submit", function (e) {
            e.preventDefault();
            var novoNome = document.getElementById("editNome").value.trim();
            var novoEmail = document.getElementById("editEmail").value.trim();
            var novaDisc = document.getElementById("editDisciplina").value.trim();
            var novaBio = document.getElementById("editBio").value.trim();

            if (!novoNome || !novoEmail || !novaDisc) {
                mostrarToast("Preencha nome, e-mail e disciplina.");
                return;
            }

            var lista = getProfessores();
            // Se ainda usa lista padrão sem localStorage
            if (!localStorage.getItem("professores")) {
                lista = getProfessores().slice();
            }
            var idx = lista.findIndex(function (p) { return p.email === usuario.email; });
            if (idx !== -1) {
                lista[idx].nome = novoNome;
                lista[idx].email = novoEmail;
                lista[idx].disciplina = novaDisc;
                lista[idx].bio = novaBio;
            } else {
                lista.push({
                    id: usuario.id || Date.now(),
                    nome: novoNome,
                    email: novoEmail,
                    disciplina: novaDisc,
                    tipo: "professor",
                    bio: novaBio
                });
            }
            setProfessores(lista);

            usuario.nome = novoNome;
            usuario.email = novoEmail;
            usuario.disciplina = novaDisc;
            usuario.bio = novaBio;
            setUsuarioLogado(usuario);

            if (nomeEl) nomeEl.textContent = novoNome;
            if (emailEl) emailEl.textContent = novoEmail;
            if (discEl) discEl.textContent = novaDisc;
            if (bioEl) bioEl.textContent = novaBio || "Nenhuma bio definida.";
            if (avatarEl) avatarEl.textContent = novoNome.charAt(0).toUpperCase();
            atualizarUIUsuario();
            mostrarToast("Perfil atualizado!");
            fecharModal("editPerfilModal");
        });
    }
}

/* ---------- Boot ---------- */

document.addEventListener("DOMContentLoaded", function () {
    var page = document.body.getAttribute("data-page") || "home";

    atualizarUIUsuario();

    if (page === "home") {
        initHomeForms();
        atualizarSelectDisciplinas();
        atualizarSelectProfessores();
        renderizarProfessores();
        renderizarCalendario();
    } else if (page === "perfil-aluno") {
        initPerfilAluno();
    } else if (page === "perfil-professor") {
        initPerfilProfessor();
    }
});

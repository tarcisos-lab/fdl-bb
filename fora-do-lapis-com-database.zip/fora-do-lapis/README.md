# Fora do Lápis — Sistema de Agendamento de Aulas

Projeto front-end (HTML + CSS + JavaScript) com armazenamento local (localStorage).

## Arquivos

- `index.html` — página principal (home, disciplinas, professores, agendamento)
- `perfil-aluno.html` — perfil do estudante
- `perfil-professor.html` — perfil do professor
- `app.js` — toda a lógica
- `style.css` — estilos
- `database/` — SQLite (schema, banco, API Python)

## Como abrir no VS Code

1. Extraia o ZIP
2. Abra a pasta `fora-do-lapis` no VS Code
3. Abra `index.html` com Live Server (ou abra direto no navegador)

## Funcionalidades

### Cadastro separado
- **Aluno**: nome, e-mail, senha
- **Professor**: nome, e-mail, senha + disciplina (lista ou personalizada)

### Login
- Reconhece aluno ou professor pelo e-mail cadastrado
- Após login, link "Meu perfil" no header

### Perfil do Aluno
- Dados pessoais
- Estatísticas (aulas totais / próximas)
- Lista de próximas aulas com opção de cancelar
- Editar nome e e-mail

### Perfil do Professor
- Dados pessoais, disciplina e bio
- Estatísticas (aulas, próximas, alunos)
- Agenda de aulas marcadas com ele
- Editar nome, e-mail, disciplina e bio



### Solicitações de agendamento (novo)
- **Aluno logado**: ao agendar, envia uma **solicitação pendente** (não confirma na hora).
- **Professor logado**: vê a aba **Solicitações** (menu e perfil) e pode **Aceitar** ou **Recusar**.
- Após aceitar, a aula aparece como **Confirmada** no perfil do aluno e no calendário dele.
- O calendário da home só marca aulas do usuário logado (privacidade por login).

### Calendário (home)
- Navegação de mês
- Dias com agendamento marcados
- Próxima aula atualizada em tempo real
- Conflito de horário do professor bloqueado

## Contas demo (já no sistema)

| Tipo       | E-mail              | Disciplina   |
|------------|---------------------|--------------|
| Professor  | gabriel@email.com   | Matemática   |
| Professor  | mariana@email.com   | Português    |
| Professor  | lucas@email.com     | Inglês       |

Use qualquer senha no login demo para esses e-mails (ou crie uma conta nova).
